# Proity Mod — Groq AI Sürümü (Minecraft Java 1.21.1 / NeoForge 21.1.259)

Bu ZIP, Proity kaynak kodunu, normal/canavar dokularını, Groq sohbetini ve ilk komut tabanlı yoldaş özelliklerini içerir.

## Derleme
- Java 21 gerekir.
- Bu bir kaynak proje ZIP'idir; önceden derlenmiş `.jar` değildir.
- Proje klasöründe `gradlew.bat build` komutunu çalıştırın. Derleme başarılı olursa JAR `build/libs/` içinde oluşur.
- Kaynak paket bu ortamda derlenerek doğrulanmamıştır; hata çıkarsa `error:` satırlarını kontrol edin.

## Proity dokusu
Oyun içi boss dokusu: `src/main/resources/assets/proitymod/textures/entity/proity.png` (64×64 PNG).
Ayrıca `proity_entity_texture_64x64.png` aynı dokunun ayrı kopyasıdır. `proity_skin_concept.png` tasarım önizlemesidir; doğrudan Minecraft'ın standart oyuncu skin yükleyicisine verilmek için garanti edilmiş bir skin şablonu değildir.

## Groq API anahtarı
1. Modu bir kez başlatın.
2. Minecraft'ın kullandığı oyun klasöründeki `config/proitymod-groq.properties` dosyasını açın.
3. `api_key=GROQ_API_KEY_BURAYA` kısmını kendi Groq API anahtarınızla değiştirin.
4. Kaydedip oyunu yeniden başlatın.

API anahtarınızı kimseyle paylaşmayın ve kaynak koduna gömmeyin. Groq API kullanımının kendi limitleri/ücretleri olabilir. Sohbete `Proity, bana bir bilmece sor.` yazıldığında mesajın Proity yanıtı üretmek için API'ye gönderilmesi amaçlanır; internet ve geçerli anahtar gerekir.

## Boss'u çağırma
`/summon proitymod:proity`


## Yeni özellikler (v1.2 kaynak paketi)
- Proity normal formda oyuncuları otomatik hedeflemez ve rastgele dolaşmaz.
- Sohbette “Proity, beni takip et”, “Proity, burada bekle”, “Proity, ev yap”, “Proity, canavar formuna geç”, “Proity, sakinleş” veya “Proity, durumunu göster” yazılabilir.
- Alternatif komutlar: `/proity follow`, `/proity stay`, `/proity build_house`, `/proity monster`, `/proity calm`, `/proity status`.
- Oyuncu Proity'ye saldırdığında öfkesi 25 artar; 100 öfkede canavar formuna geçer. Öfke uzun süre sakin kalındığında yavaşça azalır.
- Değerli eşya istekleri (elmas, zümrüt, netherit vb.) sohbet tarafından reddedilir. Bu sürümde Proity'nin eşya üretip dağıtma sistemi yoktur.
- `build_house` ilk prototip olarak yakında 7x7 ahşap bir üs kurar; blok yerleştirme yalnızca değiştirilebilir alanlarda yapılır (zemin hariç).

Not: Bu güncelleme kaynak kodudur, hazır JAR değildir. Derleme ve oyun içi test bu ortamda doğrulanamadı. Önce bir kopya dünyada test et.

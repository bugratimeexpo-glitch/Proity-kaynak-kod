package com.barlas.proitymod.client;

import com.barlas.proitymod.ProityMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientChatEvent;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;

@EventBusSubscriber(modid = ProityMod.MOD_ID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class ProityChatHandler {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15)).build();
    private static final String API_URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final String MODEL = "openai/gpt-oss-120b";

    private ProityChatHandler() {}

    @SubscribeEvent
    public static void onChat(ClientChatEvent event) {
        String message = event.getMessage();
        if (message == null) return;
        String lower = message.toLowerCase(Locale.ROOT);
        int at = lower.indexOf("proity");
        if (at < 0) return;

        String prompt = message.substring(at + "proity".length())
                .replaceFirst("^[\\s,:;.!?—-]+", "").trim();
        event.setCanceled(true);
        if (prompt.isBlank()) {
            tell("Proity: Bana bir şey sor! Örnek: Proity, beni takip et.");
            return;
        }
        if (handleGameCommand(prompt)) return;
        String normalized = prompt.toLowerCase(Locale.ROOT);
        if (asksForValuableItem(normalized)) {
            tell("Proity: Değerli eşyaları izinsiz vermem. Bu sürümde eşya dağıtma yetkim de yok.");
            return;
        }
        tell("Proity: Düşünüyorum...");
        askGroq(prompt);
    }

    private static boolean handleGameCommand(String prompt) {
        String p = prompt.toLowerCase(Locale.ROOT);
        String command = null;
        if (p.contains("beni takip") || p.contains("takip et") || p.contains("peşimden gel") || p.contains("yanıma gel")) {
            command = "proity follow";
        } else if (p.contains("burada bekle") || p.contains("yerinde kal") || p.contains("dur ve bekle")) {
            command = "proity stay";
        } else if (p.contains("ev yap") || p.contains("ev inşa") || p.contains("üs yap") || p.contains("base yap")) {
            command = "proity build_house";
        } else if (p.contains("canavar form") || p.contains("canavar ol") || p.contains("öfkeli forma geç")) {
            command = "proity monster";
        } else if (p.contains("sakinleş") || p.contains("normal haline dön") || p.contains("öfkeni sıfırla")) {
            command = "proity calm";
        } else if (p.contains("durumunu göster") || p.equals("durum") || p.contains("öfken kaç")) {
            command = "proity status";
        }
        if (command == null) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) {
            tell("Proity: Bu komut için dünyada olmalısın.");
            return true;
        }
        mc.getConnection().sendCommand(command);
        tell("Proity: Komutu uygulamaya gönderiyorum...");
        return true;
    }

    private static boolean asksForValuableItem(String p) {
        boolean asksToGive = p.contains("ver") || p.contains("getir") || p.contains("hediye et") || p.contains("bana") && p.contains("eşya");
        if (!asksToGive) return false;
        String[] valuable = {"elmas", "diamond", "zümrüt", "emerald", "netherit", "netherite", "antik kalıntı", "elytra", "totem", "nether yıldızı", "nether star", "ejderha yumurtası", "shulker", "beacon", "üç dişli", "trident", "büyülü altın elma", "enchanted golden apple"};
        for (String item : valuable) if (p.contains(item)) return true;
        return false;
    }

    private static void askGroq(String prompt) {
        String key;
        try {
            key = loadApiKey();
        } catch (IOException ex) {
            tell("Proity: API ayar dosyasını oluşturamadım: " + ex.getMessage());
            return;
        }
        if (key.isBlank() || key.equals("GROQ_API_KEY_BURAYA")) {
            tell("Proity: Groq API anahtarın ayarlı değil. .minecraft/config/proitymod-groq.properties dosyasına kendi anahtarını ekle.");
            return;
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.addProperty("temperature", 0.7);
        body.addProperty("max_tokens", 350);
        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", "Sen Proity adında, Minecraft dünyasında yaşayan, Verity ailesinin en büyük abisi olan zeki ve biraz gizemli bir karakter olarak konuşuyorsun. Türkçe ve kısa cevap ver. Eşya verme, blok yerleştirme veya komut çalıştırma yeteneğin yoksa bunları yaptığını ASLA iddia etme. Elmas, zümrüt, netherit, antik kalıntı, elytra, totem, nether yıldızı, ejderha yumurtası ve diğer değerli eşyaları izinsiz verme veya verdiğini söyleme. Kullanıcıya desteklenen komutları önerebilirsin: beni takip et, burada bekle, ev yap, canavar formuna geç, sakinleş, durumunu göster. Tehlikeli istekleri reddet.");
        messages.add(system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", prompt);
        messages.add(user);
        body.add("messages", messages);

        HttpRequest request = HttpRequest.newBuilder(URI.create(API_URL))
                .timeout(Duration.ofSeconds(45))
                .header("Authorization", "Bearer " + key)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();

        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                .thenApply(response -> {
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        throw new RuntimeException("Groq HTTP " + response.statusCode() + ": " + response.body());
                    }
                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                            .getAsJsonObject("message").get("content").getAsString().trim();
                })
                .whenComplete((answer, error) -> Minecraft.getInstance().execute(() -> {
                    if (error != null) {
                        String reason = error.getCause() != null ? error.getCause().getMessage() : error.getMessage();
                        if (reason == null) reason = "Bilinmeyen bağlantı hatası";
                        if (reason.length() > 180) reason = reason.substring(0, 180) + "...";
                        tell("Proity: Groq bağlantı hatası: " + reason);
                    } else {
                        tell("Proity: " + answer);
                    }
                }));
    }

    private static String loadApiKey() throws IOException {
        Path file = FMLPaths.CONFIGDIR.get().resolve("proitymod-groq.properties");
        if (Files.notExists(file)) {
            Files.createDirectories(file.getParent());
            Files.writeString(file, "# Anahtarını buraya yapıştır. Bu dosyayı kimseyle paylaşma.\napi_key=GROQ_API_KEY_BURAYA\n", StandardCharsets.UTF_8);
            return "";
        }
        Properties properties = new Properties();
        try (var reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            properties.load(reader);
        }
        return properties.getProperty("api_key", "").trim();
    }

    private static void tell(String text) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null) mc.player.displayClientMessage(Component.literal(text), false);
        });
    }
}

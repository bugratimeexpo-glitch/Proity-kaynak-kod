package com.barlas.proitymod;

import com.barlas.proitymod.entity.ProityEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;

import java.util.Comparator;

@EventBusSubscriber(modid = ProityMod.MOD_ID, bus = EventBusSubscriber.Bus.GAME)
public final class ProityCommands {
    private ProityCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("proity")
            .then(Commands.literal("follow").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                ProityEntity p = findProity(player);
                if (p == null) return say(ctx.getSource(), "Yakında Proity yok. Önce /summon proitymod:proity yaz.");
                p.setFollowing(player);
                return say(ctx.getSource(), "Proity: Tamam, seni takip ediyorum.");
            }))
            .then(Commands.literal("stay").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                ProityEntity p = findProity(player);
                if (p == null) return say(ctx.getSource(), "Yakında Proity yok. Önce /summon proitymod:proity yaz.");
                p.setStaying(true);
                return say(ctx.getSource(), "Proity: Burada bekleyeceğim.");
            }))
            .then(Commands.literal("build_house").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                if (!(player.level() instanceof ServerLevel level)) return 0;
                BlockPos base = player.blockPosition().relative(player.getDirection(), 4);
                buildHouse(level, base);
                ProityEntity p = findProity(player);
                if (p != null) p.setStaying(true);
                return say(ctx.getSource(), "Proity: Ev planını uyguladım. Bu ilk sürümde 7x7 ahşap bir üs yaptım.");
            }))
            .then(Commands.literal("monster").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                ProityEntity p = findProity(player);
                if (p == null) return say(ctx.getSource(), "Yakında Proity yok. Önce /summon proitymod:proity yaz.");
                p.enterMonsterForm();
                return say(ctx.getSource(), "Proity: Öfkemi serbest bırakıyorum...");
            }))
            .then(Commands.literal("calm").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                ProityEntity p = findProity(player);
                if (p == null) return say(ctx.getSource(), "Yakında Proity yok.");
                p.calmDown();
                return say(ctx.getSource(), "Proity: Sakinleştim. Her şey yolunda.");
            }))
            .then(Commands.literal("status").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                ProityEntity p = findProity(player);
                if (p == null) return say(ctx.getSource(), "Yakında Proity yok.");
                return say(ctx.getSource(), "Proity | Öfke: " + p.getAnger() + "/100 | Form: " + (p.isMonsterForm() ? "Canavar" : "Normal"));
            }))
        );
    }

    private static int say(net.minecraft.commands.CommandSourceStack source, String message) {
        source.sendSuccess(() -> Component.literal(message), false);
        return Command.SINGLE_SUCCESS;
    }

    private static ProityEntity findProity(ServerPlayer player) {
        return player.level().getEntitiesOfClass(ProityEntity.class, player.getBoundingBox().inflate(64.0D))
                .stream().min(Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
    }

    private static void buildHouse(ServerLevel level, BlockPos base) {
        // Small 7x7 cabin. Only replaceable blocks are overwritten above ground to avoid deleting builds.
        BlockState floor = Blocks.COBBLESTONE.defaultBlockState();
        BlockState wall = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState roof = Blocks.SPRUCE_PLANKS.defaultBlockState();
        BlockState glass = Blocks.GLASS.defaultBlockState();
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                place(level, base.offset(x, 0, z), floor, true);
                for (int y = 1; y <= 3; y++) {
                    boolean edge = Math.abs(x) == 3 || Math.abs(z) == 3;
                    if (!edge) continue;
                    // Leave a two-block doorway on the side facing the player.
                    boolean doorway = z == 3 && x == 0 && y <= 2;
                    if (doorway) continue;
                    boolean window = y == 2 && ((x == -3 || x == 3) && z == 0 || (z == -3) && x == 0);
                    place(level, base.offset(x, y, z), window ? glass : wall, false);
                }
                place(level, base.offset(x, 4, z), roof, false);
            }
        }
    }

    private static void place(ServerLevel level, BlockPos pos, BlockState state, boolean floor) {
        if (floor || level.getBlockState(pos).canBeReplaced()) level.setBlock(pos, state, 3);
    }
}

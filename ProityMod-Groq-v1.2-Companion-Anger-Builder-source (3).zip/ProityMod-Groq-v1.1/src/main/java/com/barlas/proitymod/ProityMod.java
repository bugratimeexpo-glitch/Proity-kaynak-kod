package com.barlas.proitymod;

import com.barlas.proitymod.entity.ModEntities;
import com.barlas.proitymod.entity.ProityEntity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

@Mod(ProityMod.MOD_ID)
public class ProityMod {
    public static final String MOD_ID = "proitymod";

    public ProityMod(IEventBus modBus) {
        ModEntities.ENTITY_TYPES.register(modBus);
        modBus.addListener(this::registerAttributes);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.PROITY.get(), ProityEntity.createAttributes().build());
    }
}

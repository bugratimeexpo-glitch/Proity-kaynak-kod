package com.barlas.proitymod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/** Proity starts as a calm companion. Repeated attacks raise his anger and unlock monster form. */
public class ProityEntity extends net.minecraft.world.entity.monster.Monster {
    private static final EntityDataAccessor<Boolean> DATA_MONSTER_FORM =
            SynchedEntityData.defineId(ProityEntity.class, EntityDataSerializers.BOOLEAN);
    private int powerCooldown = 0;
    private int teleportCooldown = 0;
    private int anger = 0;
    private int lastAngerTick = 0;
    private boolean monsterForm = false;
    private boolean staying = false;
    private UUID followOwner;

    public ProityEntity(EntityType<? extends net.minecraft.world.entity.monster.Monster> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("Proity"));
        this.setCustomNameVisible(true);
        this.xpReward = 100;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_MONSTER_FORM, false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.monster.Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.38D)
                .add(Attributes.ATTACK_DAMAGE, 18.0D)
                .add(Attributes.ARMOR, 18.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D);
    }

    @Override
    protected void registerGoals() {
        // No random wandering or automatic attacks in calm form.
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    public int getAnger() { return anger; }
    public boolean isMonsterForm() { return this.entityData.get(DATA_MONSTER_FORM); }

    public void setFollowing(Player player) {
        this.followOwner = player.getUUID();
        this.staying = false;
        this.getNavigation().stop();
    }

    public void setStaying(boolean stay) {
        this.staying = stay;
        if (stay) {
            this.followOwner = null;
            this.getNavigation().stop();
        }
    }

    public void enterMonsterForm() {
        this.anger = 100;
        this.monsterForm = true;
        this.entityData.set(DATA_MONSTER_FORM, true);
        this.staying = false;
        this.followOwner = null;
        this.lastAngerTick = this.tickCount;
        this.setCustomName(Component.literal("Proity [CANAVAR]"));
        this.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 60, 1));
        this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 60, 0));
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.DRAGON_BREATH, getX(), getY() + 1.2D, getZ(), 90, 1.0D, 1.0D, 1.0D, 0.08D);
            server.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1.0D, getZ(), 70, 0.8D, 1.0D, 0.8D, 0.12D);
        }
    }

    public void calmDown() {
        this.anger = 0;
        this.monsterForm = false;
        this.entityData.set(DATA_MONSTER_FORM, false);
        this.setTarget(null);
        this.setCustomName(Component.literal("Proity"));
        this.removeEffect(MobEffects.DAMAGE_BOOST);
        this.removeEffect(MobEffects.MOVEMENT_SPEED);
        this.powerCooldown = 0;
        this.teleportCooldown = 0;
    }

    private void raiseAnger(int amount) {
        if (monsterForm) return;
        anger = Math.min(100, anger + amount);
        lastAngerTick = tickCount;
        if (anger >= 100) enterMonsterForm();
        else if (level() instanceof ServerLevel server && tickCount % 5 == 0) {
            server.sendParticles(ParticleTypes.WITCH, getX(), getY() + 1.3D, getZ(), 8, 0.45D, 0.6D, 0.45D, 0.02D);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean accepted = super.hurt(source, amount);
        if (accepted && !level().isClientSide && source.getEntity() instanceof Player) {
            raiseAnger(25);
        }
        return accepted;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        if (powerCooldown > 0) powerCooldown--;
        if (teleportCooldown > 0) teleportCooldown--;

        // Anger slowly fades only after a long peaceful period; repeated attacks accumulate it.
        if (!monsterForm && anger > 0 && tickCount % 100 == 0 && tickCount - lastAngerTick > 200) {
            anger = Math.max(0, anger - 1);
        }

        if (!monsterForm) {
            setTarget(null);
            if (staying) {
                getNavigation().stop();
            } else if (followOwner != null && level() instanceof ServerLevel server) {
                Player owner = server.getPlayerByUUID(followOwner);
                if (owner == null || !owner.isAlive() || owner.level() != level()) {
                    followOwner = null;
                    getNavigation().stop();
                } else {
                    double d = distanceToSqr(owner);
                    if (d > 3.0D * 3.0D) getNavigation().moveTo(owner, 1.15D);
                    else getNavigation().stop();
                }
            }
        } else if (tickCount % 20 == 0) {
            Player nearest = level().getNearestPlayer(this, 24.0D);
            if (nearest != null && nearest.isAlive()) setTarget(nearest);
        }

        if (this.level() instanceof ServerLevel serverLevel) {
            if (this.tickCount % 4 == 0) {
                serverLevel.sendParticles(monsterForm ? ParticleTypes.DRAGON_BREATH : ParticleTypes.PORTAL,
                        getX(), getY() + 1.4D, getZ(), monsterForm ? 12 : 5, 0.45D, 0.8D, 0.45D, 0.02D);
                if (monsterForm && tickCount % 10 == 0) {
                    serverLevel.sendParticles(ParticleTypes.WITCH, getX(), getY() + 1.2D, getZ(), 5, 0.3D, 0.6D, 0.3D, 0.02D);
                }
            }

            LivingEntity target = getTarget();
            if (monsterForm && target != null && target.isAlive()) {
                double distance = distanceToSqr(target);
                if (powerCooldown <= 0 && distance < 14.0D * 14.0D) {
                    powerCooldown = 100;
                    AABB area = getBoundingBox().inflate(6.0D);
                    for (Player player : level().getEntitiesOfClass(Player.class, area)) {
                        if (player.isAlive()) {
                            player.hurt(damageSources().mobAttack(this), 10.0F);
                            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 1));
                            Vec3 push = player.position().subtract(position()).normalize().scale(1.1D);
                            player.push(push.x, 0.45D, push.z);
                        }
                    }
                    serverLevel.sendParticles(ParticleTypes.DRAGON_BREATH,
                            getX(), getY() + 1.0D, getZ(), 70, 2.2D, 1.0D, 2.2D, 0.08D);
                }
                if (teleportCooldown <= 0 && distance > 7.0D * 7.0D && distance < 24.0D * 24.0D) {
                    teleportCooldown = 160;
                    double nx = target.getX() - 2.0D;
                    double ny = target.getY();
                    double nz = target.getZ() - 2.0D;
                    if (level().noCollision(getBoundingBox().move(nx - getX(), ny - getY(), nz - getZ()))) {
                        teleportTo(nx, ny, nz);
                        serverLevel.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1, getZ(), 45, 0.8D, 1.0D, 0.8D, 0.1D);
                    }
                }
                if (this.tickCount % 200 == 0) {
                    addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 1));
                    addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 80, 0));
                }
            }
        }
    }
}

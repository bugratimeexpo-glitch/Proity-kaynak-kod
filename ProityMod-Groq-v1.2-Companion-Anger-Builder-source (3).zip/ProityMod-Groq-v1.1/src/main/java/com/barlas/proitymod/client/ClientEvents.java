package com.barlas.proitymod.client;

import com.barlas.proitymod.ProityMod;
import com.barlas.proitymod.entity.ModEntities;
import com.barlas.proitymod.entity.ProityEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = ProityMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.PROITY.get(), ProityRenderer::new);
    }

    public static class ProityRenderer extends HumanoidMobRenderer<ProityEntity, HumanoidModel<ProityEntity>> {
        private static final ResourceLocation TEXTURE =
                ResourceLocation.fromNamespaceAndPath(ProityMod.MOD_ID, "textures/entity/proity.png");

        public ProityRenderer(EntityRendererProvider.Context context) {
            super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.65F);
        }

        @Override
        public ResourceLocation getTextureLocation(ProityEntity entity) {
            return entity.isMonsterForm()
                    ? ResourceLocation.fromNamespaceAndPath(ProityMod.MOD_ID, "textures/entity/proity_monster.png")
                    : TEXTURE;
        }
    }
}

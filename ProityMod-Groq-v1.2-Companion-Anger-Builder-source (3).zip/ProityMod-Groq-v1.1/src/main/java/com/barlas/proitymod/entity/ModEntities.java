package com.barlas.proitymod.entity;

import com.barlas.proitymod.ProityMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ProityMod.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<ProityEntity>> PROITY =
            ENTITY_TYPES.register("proity", () -> EntityType.Builder
                    .of(ProityEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.7F)
                    .clientTrackingRange(10)
                    .build("proity"));

    private ModEntities() {}
}
